namespace LostInWoods.Models
{
    public abstract class BaseEntity {}
}