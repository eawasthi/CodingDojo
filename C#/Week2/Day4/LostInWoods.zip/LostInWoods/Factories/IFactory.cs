using LostInWoods.Models;
using System.Collections.Generic;
namespace LostInWoods.Factory
{
    public interface IFactory<T> where T : BaseEntity
    {
    }
}