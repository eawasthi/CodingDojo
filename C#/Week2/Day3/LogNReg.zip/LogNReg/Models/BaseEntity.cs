namespace LogNReg.Models
{
    public abstract class BaseEntity {}
}