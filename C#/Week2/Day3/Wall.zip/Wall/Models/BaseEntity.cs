namespace Wall.Models
{
    public abstract class BaseEntity {}
}