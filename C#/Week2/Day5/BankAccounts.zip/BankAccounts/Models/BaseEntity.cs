namespace BankAccounts
{
    public abstract class BaseEntity {}
}