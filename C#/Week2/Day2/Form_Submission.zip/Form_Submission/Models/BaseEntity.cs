namespace Form_Submission.Models
{
    public abstract class BaseEntity {}
}