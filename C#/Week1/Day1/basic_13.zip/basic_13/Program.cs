﻿using System;
using System.Collections.Generic;
namespace basic_13
{
    class Program
    {
        static void Main(string[] args)
         {
    //    int[] arr = new int[5] {1,5,6,7,4};
    //     int[] arr = { 1, 3, 5, 7, 9 };
       
        
            // NumLoop();
            // OddNum();
            // Sum();
            // Array(arr);
            // findMax(arr);
            // findAvg(arr);
            // findodd();
            // MinMaxAvg(arr);
            // object[] boxedArray = new object[] {-1,"asd",4,-2};
            // System.Console.WriteLine(boxedArray[2]);
            // ReplaceNumberWithString(boxedArray);
            // OddArray();

            

       }
    //     public static void NumLoop(){
    //         for ( int i = 1; i <= 255; i++){
    //             System.Console.WriteLine(i);
    //         } 
    //         Print odd numbers between 1-255
    //         Write a program (sets of instructions) that would print all the odd numbers from 1 to 255.
    //     public static void OddNum(){
    //         for ( int i = 1; i <= 255; i++){
    //             if(i % 2 != 0){
    //                 System.Console.WriteLine(i);
    //             }
    //         }
    //  }
    //     public static void Sum(){
    //         int sum = 0;
    //         for ( int i = 1; i <= 255; i++){
    //             sum = sum + (int)i;
    //             System.Console.WriteLine(sum);
    //             System.Console.WriteLine(i);
    //             }
    //         }
    //       public static void Array(int[] arr){
    //         for ( int i =0; i<arr.Length; i++){
    //            System.Console.WriteLine(arr[i]);
    //             }
        
    //         }
    //        public static void findMax(int[] arr){
    //            int max = arr[0];
    //         for ( int i =0; i<arr.Length; i++){
    //            if (arr[i] > max){
    //                 max = arr[i];
    //              }
    //           }
    //             System.Console.WriteLine(max);
    //         }

    //       public static void findAvg(int[] arr){
    //            int sum = 0;
    //         for ( int i =0; i<arr.Length; i++){
    //             sum += arr[i];
    //              }
    //               System.Console.WriteLine(sum/arr.Length);
    //           }

    //         public static int[] OddArray(){
    //        List<int> odd = new List<int>();
    //             for ( int i =0; i<= 255; i++){
    //                 System.Console.WriteLine("before if condition ---> "+ odd );
    //                 if ( i % 2 != 0){
    //                     odd.Add(i);
    //                 }
    //             }
    //         return odd.ToArray();
    //         }

    //        public static void findodd(){
    //      int[] oddnumbers ={};
    //         for ( int i =1; i<256; i++){
    //             if(i%2!=0){
    //                 oddnumbers[] = i;
    //             }
    //              }
    //               System.Console.WriteLine(oddnumbers);
    //           }

    //     public static void MinMaxAvg(int[] arr){
    //         int sum = 0;
    //         int max = arr[0];
    //         int min = arr[0];
    //         int avg = 0;
    //         for ( int idx = 0; idx<arr.Length; idx++){
    //             sum = sum + arr[idx];
    //             if (arr[idx] > max){
    //                 max = arr[idx];
    //             }
    //             if (arr[idx] < min){
    //                 min = arr[idx];
    //             }
    //             }
    //          avg = sum/arr.Length;
    //          System.Console.WriteLine(" avg is " + avg + " max is " + max + " min is " + min );
    //         }

    //     public static void ShiftArray(int[] arr){
    //         for(int idx =0; idx<arr.Length-1; idx++){
    //             arr[idx] = arr[idx+1];
    //         }
    //         arr[arr.Length-1] = 0;
    //     }
    //     public static object[] ReplaceNumberWithString(object[] arr){
    //         object mystring = "ssdfsdf";
    //       for(int idx =0; idx<arr.Length; idx++){
    //           if((int)arr[idx] < 0 ){
    //               arr[idx] = "Dojo";
    //           }
    //     }
    //     System.Console.WriteLine(arr);
    //    return arr;
    // }
 }
 }

