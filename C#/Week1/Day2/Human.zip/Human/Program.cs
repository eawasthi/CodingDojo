﻿using System;

namespace Human
{
    class Program
    {
        public static void Main(string[] args)
        {
            Humans myHumans = new Humans("Ekta");
        }
    }
}
