namespace Wishlist
{
    public abstract class BaseEntity {}
}