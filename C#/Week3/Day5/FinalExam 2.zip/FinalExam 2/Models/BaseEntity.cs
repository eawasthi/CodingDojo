namespace FinalExam
{
    public abstract class BaseEntity {}
}