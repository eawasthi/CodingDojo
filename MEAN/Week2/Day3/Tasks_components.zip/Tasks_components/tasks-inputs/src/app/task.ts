export class Task {
	title: string
	completed: boolean
}
