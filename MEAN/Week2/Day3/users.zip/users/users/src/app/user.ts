export class User {
	name: string
	date: Date 
}
