#Mongoose Dashboard Checklist

#create a root route which is going display all our mongoose from our database.
# When you click on root image, redirect to specfic mongoose page.
# on this page, you can edit and remove this mongoose. Information about this moongoose is displayed from database.
