export class Trivia {
    question1Id:any
    question2Id:any
    question3Id:any
    rightAnswer1:any
    rightAnswer2:any
    rightAnswer3:any
}
