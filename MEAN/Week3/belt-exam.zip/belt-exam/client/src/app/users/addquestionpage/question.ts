export class Question {

}
