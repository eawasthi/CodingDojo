import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchPipe'
})
export class SearchPipePipe implements PipeTransform {

  transform(value: any[], search_pipe: string): any {
    if(!search_pipe) {return value}

    return value.filter(result => result.Title.indexOf(search_pipe) > -1 || result.Description.indexOf(search_pipe) > -1)
  }
}
