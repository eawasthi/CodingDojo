import { User } from './login/user';
import { Injectable } from '@angular/core';
import { Http,Response,RequestOptions,Headers } from "@angular/http";
import "rxjs";
import { Bucket } from "app/users/mainpage/bucket";

@Injectable()
export class UsersService {
  UPDATE: any;
  AnyUserBucket: any;
  CurrentUserTaggedBucket: any;
  CurrentUserBucket: any;
  user: User;
  loggedUser: User;
  USERS: User[] = []
  loggedin = false
  mainpage = false
  dashboard = false
  userFind: String;
  showPage = false
 
  constructor(private http:Http) {}

get_users(){
    this.http.get('/users')
      .map((response: Response) => response.json())
      .subscribe(
      data => {this.USERS=data},
      )}

  loggedIn(){
    console.log("Hitting logged in in service ts")
    this.http.get('/loggedin')
      .map((response: Response) => response.json())
      .subscribe(user=>{if(user){{this.loggedin = true; this.loggedUser=user}}else{this.loggedin = false}},
      )
  }

  create(user:User){
    this.http.post("/create", user)
      .map((response: Response)=> response.json())
      .subscribe(userinfo =>{console.log("Server returned this userinfo.body: ",userinfo);
        this.loggedUser = userinfo;
        this.loggedin = true
      })
    }

    find(user:User){
      this.http.post("/find", user)
          .map((response: Response) => response.json())
          .subscribe(data2 =>{
            if(data2==null){
              console.log("User was not found"); 
              this.create(user);
            }else{ 
              console.log("User was found: ", data2);
              this.loggedUser = data2
              this.loggedin = true
          }
        })
    }

    logOut(){
      console.log("hitting logout service")
      this.http.get("/logout")
          .map((response: Response) => response.json())
          .subscribe()
          this.loggedin = false  
          this.mainpage = false
          this.dashboard = false
    }
    
     home(){
        this.dashboard=false  
        this.mainpage=true
     }

      bucketList(){
        console.log("hitting bucketlist")
        this.mainpage=false
        console.log("hitting bucketlist again")
        this.dashboard=true  
     }

     addbucket(bucket: Bucket){
       console.log("adding bucket to users service", bucket)
        this.http.post("/createBucketlist", bucket)
        .map((response: Response) => response.json())
        .subscribe(data => {this.bucketList = data})
        this.http.get('/getCurrentUserBucket')
      .map((response: Response) => response.json())
      .subscribe(
      data => {this.CurrentUserBucket=data},
      )
      }

      get_currentBucket(){
        this.http.get('/getCurrentUserBucket')
      .map((response: Response) => response.json())
      .subscribe(
      data => {this.CurrentUserBucket=data},
      )}

     findUser(id: string){
      this.userFind = id
      this.http.get("/getAnyUserBucket/"+id)
      .map((response: Response) => response.json())
      .subscribe(data => {this.AnyUserBucket = data})
      this.mainpage = false
      this.dashboard = true
    }
    
  Status(id:string){
      console.log("hitting Status service", id)
      this.http.get('/updateStatus/'+id)
        .map((response: Response) =>response.json())
        .subscribe(data => this.UPDATE = data);
        console.log("this is data thats coming back from controller", this.UPDATE)
    }
  }