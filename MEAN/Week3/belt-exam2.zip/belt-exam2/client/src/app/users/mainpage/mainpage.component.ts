import { UsersService } from '../users.service';
import { Component, OnInit } from '@angular/core';
import { Bucket } from "app/users/mainpage/bucket";

@Component({
  selector: 'app-mainpage',
  templateUrl: './mainpage.component.html',
  styleUrls: ['./mainpage.component.css']
})
export class MainpageComponent implements OnInit {
   newBucket: Bucket = new Bucket()

constructor(private _usersService: UsersService) { }

  ngOnInit() {
   this._usersService.get_users()
   this._usersService.get_currentBucket()
   this._usersService.loggedIn()
  }

  home(){
    this._usersService.home()
  }

  bucketList(){
    this._usersService.bucketList()
  }

  addbucket(){
    this._usersService.addbucket(this.newBucket)
    this.newBucket= new Bucket()
  }

  User(id){
    this._usersService.findUser(id)
  }


  checkbox(id){
  console.log("hitting status component")
  this._usersService.Status(id);
  }
}
