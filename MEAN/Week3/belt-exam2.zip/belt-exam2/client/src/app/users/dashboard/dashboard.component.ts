import { UsersService } from '../users.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  newBucket: any;

constructor(private _usersService: UsersService) { }

  ngOnInit() {
    this._usersService.get_currentBucket()
    this._usersService.get_users
    this._usersService.loggedIn()
  }



  addbucket(){
    this._usersService.addbucket(this.newBucket)
  } 

  checkbox(id){
  console.log("hitting status component")
  this._usersService.Status(id);
  }
}
