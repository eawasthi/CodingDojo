export class Bucket {
}
